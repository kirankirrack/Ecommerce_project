from django.shortcuts import render,redirect
from django.http import HttpResponse
import requests
from bs4 import BeautifulSoup
from django.contrib.auth.models import User
from django.contrib.auth import authenticate,login,logout
from ecommerceapp.models import Useradd, Contact
from django.contrib.auth.decorators import login_required

# Create your views here.

# def templates(request):
#    return render(request,"base.html")
#Iphone

response=requests.get("https://www.flipkart.com/search?q=iphone&otracker=search&otracker1=search&marketplace=FLIPKART&as-show=on&as=off")
soup=BeautifulSoup(response.content, "html.parser")
names=soup.find_all('div',class_='_2kHMtA')
ratings=soup.find_all('div',class_='_3LWZlK')
prices=soup.find_all('div',class_='_30jeq3 _1_WHN1')
images=soup.find_all('img',class_='_396cs4')
links=soup.find_all('a',class_='_blank')

name=[]
rating=[]
price=[]
image=[]
link=[]

for i in names[0:20]:
    n=i.get_text()
    name.append(n)
for i in ratings[0:20]:
    n=i.get_text()
    rating.append(float(n))
for i in prices[0:20]:
    n=i.get_text()
    price.append(n)
for i in images[0:20]:
    n=i['src']
    image.append(n)
for i in links[0:20]:
    n="https://www.flipkart.com/"+i['href']
    link.append(n)

mylist=zip(name,
           rating,
           price,
           image,
           link)
def iphone(request):
    return render(request,'iphone.html',{'mylist':mylist})


#Tecno

response=requests.get("https://www.flipkart.com/search?q=techno&otracker=search&otracker1=search&marketplace=FLIPKART&as-show=on&as=off")
soup=BeautifulSoup(response.content, "html.parser")
names=soup.find_all('div',class_='_4rR01T')
ratings=soup.find_all('div',class_='_3LWZlK')
prices=soup.find_all('div',class_='_30jeq3 _1_WHN1')
images=soup.find_all('img',class_='_396cs4')
links=soup.find_all('a',class_='_1fQZEK')

name=[]
rating=[]
price=[]
image=[]
link=[]

for i in names[0:20]:
    n=i.get_text()
    name.append(n)
for i in ratings[0:20]:
    n=i.get_text()
    rating.append(float(n))
for i in prices[0:20]:
    n=i.get_text()
    price.append(n)
for i in images[0:20]:
    n=i['src']
    image.append(n)
for i in links[0:20]:
    n="https://www.flipkart.com/"+i['href']
    link.append(n)

mylist1=zip(name,
           rating,
           price,
           image,
           link)
def techno(request):
    return render(request,'techno.html',{'mylist1':mylist1})
    


#Redmi

response=requests.get("https://www.flipkart.com/search?q=redmi&otracker=search&otracker1=search&marketplace=FLIPKART&as-show=on&as=off")
soup=BeautifulSoup(response.content, "html.parser")
names=soup.find_all('div',class_='_4rR01T')
ratings=soup.find_all('div',class_='_3LWZlK')
prices=soup.find_all('div',class_='_30jeq3 _1_WHN1')
images=soup.find_all('img',class_='_396cs4')
links=soup.find_all('a',class_='_1fQZEK')

name=[]
rating=[]
price=[]
image=[]
link=[]

for i in names[0:20]:
    n=i.get_text()
    name.append(n)
for i in ratings[0:20]:
    n=i.get_text()
    rating.append(float(n))
for i in prices[0:20]:
    n=i.get_text()
    price.append(n)
for i in images[0:20]:
    n=i['src']
    image.append(n)
for i in links[0:20]:
    n="https://www.flipkart.com/"+i['href']
    link.append(n)

mylist2=zip(name,
           rating,
           price,
           image,
           link)
def redmi(request):
    return render(request,'redmi.html',{'mylist2':mylist2})


response=requests.get("https://www.flipkart.com/mobile-phones-store?otracker=nmenu_sub_Electronics_0_Mobiles")
soup=BeautifulSoup(response.content, "html.parser")
names=soup.find_all('h1',class_='_3vKRL2')
images=soup.find_all('img',class_='kJjFO0')
links=soup.find_all('a',class_='_2a3TMW')

name=[]
image=[]
link=[]

for i in names:
    n=i.get_text()
    name.append(n)
for i in images:
    n=i['src']
    image.append(n)
for i in links:
    n="https://www.flipkart.com/"+i['href']
    link.append(n)

mylist3=zip(name,
           image,
           link)

@login_required (login_url='login')
def ecommerce(request):
    return render(request,'base.html',{'mylist3':mylist3})


def login_user(request):
    if request.method=="POST":
        username=request.POST.get("username")
        password=request.POST.get("password")
        user= authenticate(username=username, password=password)
        if user is not None:

            login(request,user)
        
        return redirect("home")

    return render(request,"login.html")
def register(request):
    if request.method=="POST":
        username=request.POST.get("username")
        password=request.POST.get("password")
        email=request.POST.get("email")
        c = User.objects.create_user(username=username,email=email,password=password)
        c.save()
        return redirect("login")
    
    return render(request,"register.html")

def logout_user(request):
    logout(request)
    return redirect("login")

def contact(request):
    if request.method=="POST":
        name=request.POST['name']
        email=request.POST['email']
        message=request.POST['message']
        


        c=Contact(name=name,email=email,message=message)
        c.save()
    return redirect("home")

    return render(request,"contact.html")

